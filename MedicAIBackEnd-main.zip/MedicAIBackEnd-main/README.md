1. git clone or download zip
2. navigate to root directory
3. create .env file in root directory
4. Add the following to the .env file:
5. PORT=8000
6. DATABASE=enterYourMongoDBStringWithUsernameAndPassword
7. JWT_SECRET=LKAJSDFHJKS"+!%SDFG345+!%/GSDFGSDFG345
5. run the command "npm install" in your terminal from the root
